<div align="center">

<img src="assets/hero.svg" alt="FEL.PSDEV - Desenvolvedor Front-End" width="100%" />

<img src="assets/frases.svg" alt="Sites que dão cara ao seu negócio. HTML, CSS e JavaScript. Lógica de programação todo dia." width="100%" />

<img src="assets/sec-sobre.svg" alt="Sobre mim" width="100%" />

</div>

Fala! Eu sou o **Felipe**, dev front-end em formação e estudante de **Análise e Desenvolvimento de Sistemas**, aqui de Araxá-MG. Desenvolvo sites para negócios locais e uso projetos de lógica de programação para afiar o raciocínio.

- 🔨 Construindo sites reais para clientes, sob a marca **FEL.PSDEV**
- 🧠 Praticando lógica de programação em JavaScript
- 🎯 Buscando minha primeira vaga de dev, remota ou híbrida

<div align="center">

<img src="assets/sec-tech.svg" alt="Tecnologias" width="100%" />

<img src="https://img.shields.io/badge/-HTML5-000000?style=for-the-badge&logo=html5&logoColor=D4AF37" alt="HTML5" />
<img src="https://img.shields.io/badge/-CSS3-000000?style=for-the-badge&logo=css3&logoColor=D4AF37" alt="CSS3" />
<img src="https://img.shields.io/badge/-JavaScript-000000?style=for-the-badge&logo=javascript&logoColor=D4AF37" alt="JavaScript" />
<img src="https://img.shields.io/badge/-Git-000000?style=for-the-badge&logo=git&logoColor=D4AF37" alt="Git" />
<img src="https://img.shields.io/badge/-GitHub-000000?style=for-the-badge&logo=github&logoColor=D4AF37" alt="GitHub" />

<img src="assets/sec-projetos.svg" alt="Projetos" width="100%" />

</div>

| Projeto | O que faz | Stack |
|---|---|---|
| [🚗 Calculadora de Consumo](https://github.com/FelpsProg/Calculadora-De-Consumo) | Calcula o consumo médio de combustível (km/l) | HTML, CSS, JavaScript |
| 🔜 Lógica de programação | Jogos e algoritmos em JavaScript, em construção | JavaScript |

<div align="center">

<img src="assets/sec-stats.svg" alt="Estatísticas" width="100%" />

<img src="https://github-readme-stats.vercel.app/api?username=FelpsProg&show_icons=true&hide_border=false&bg_color=000000&title_color=D4AF37&text_color=EDE6D3&icon_color=D4AF37&border_color=D4AF37" alt="Estatísticas do GitHub" />

<img src="assets/sec-contato.svg" alt="Contato" width="100%" />

<a href="https://instagram.com/fel.psdev"><img src="https://img.shields.io/badge/-@fel.psdev-000000?style=for-the-badge&logo=instagram&logoColor=D4AF37" alt="Instagram" /></a>
<a href="https://www.linkedin.com/in/felipe-silva-6287ab25b"><img src="https://img.shields.io/badge/-LinkedIn-000000?style=for-the-badge&logo=linkedin&logoColor=D4AF37" alt="LinkedIn" /></a>

</div>
